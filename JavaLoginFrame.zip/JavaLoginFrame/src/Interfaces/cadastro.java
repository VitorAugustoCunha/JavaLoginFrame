package Interfaces;

public class cadastro {

}
